import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { RoleGuard } from "@/components/g3/role-guard";
import { G3Logo } from "@/components/g3/logo";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ContractorAddLeadDialog } from "@/components/g3/contractor-add-lead-dialog";
import { useAuth } from "@/lib/auth";
import { LogOut, Plus, Settings as SettingsIcon, User } from "lucide-react";

export const Route = createFileRoute("/contractor")({
  component: () => (
    <RoleGuard role="contractor">
      <ContractorLayout />
    </RoleGuard>
  ),
});

function ContractorLayout() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif" }}>
      <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-4 border-b border-border bg-background/80 px-6 backdrop-blur">
        <div className="flex items-center gap-3">
          <G3Logo />
          <span className="hidden text-[11px] uppercase tracking-widest text-muted-foreground sm:inline">
            Elite Technical Search
          </span>
          <nav className="ml-4 hidden items-center gap-1 md:flex">
            <Link
              to="/contractor"
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${pathname === "/contractor" ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >My Leads</Link>
            <Link
              to="/contractor/settings"
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${pathname.startsWith("/contractor/settings") ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >Settings</Link>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <ContractorAddLeadDialog
            trigger={
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm">
                <Plus className="h-3.5 w-3.5" /> Add a Lead
              </Button>
            }
          />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-semibold">
                {(user?.name ?? "C").slice(0, 1)}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="text-xs">
                <div className="font-medium">{user?.name}</div>
                <div className="text-muted-foreground">{user?.email}</div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate({ to: "/contractor/settings" })}>
                <User className="h-3.5 w-3.5" /> My profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate({ to: "/contractor/settings" })}>
                <SettingsIcon className="h-3.5 w-3.5" /> Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => { signOut(); navigate({ to: "/login", replace: true }); }}>
                <LogOut className="h-3.5 w-3.5" /> Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
      <main className="px-6 py-6">
        <Outlet />
      </main>
    </div>
  );
}