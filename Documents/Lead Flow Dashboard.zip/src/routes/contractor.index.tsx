import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ContractorAddLeadDialog } from "@/components/g3/contractor-add-lead-dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, ContactRound, Plus } from "lucide-react";
import { myContractorLeads, useRecruiterStore, type RecruiterLead } from "@/lib/recruiter-mock";

export const Route = createFileRoute("/contractor/")({
  component: MyLeadsPage,
});

function MyLeadsPage() {
  // Subscribe to the shared store so new submissions render instantly.
  useRecruiterStore();
  const leads = useMemo(() => myContractorLeads().sort((a, b) => b.created_at - a.created_at), []);
  const dupCount = leads.filter((l) => l.dup_flagged).length;

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">My Leads</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Every lead you've submitted. Enrichment and outreach are handled by the team.
          </p>
        </div>
        <ContractorAddLeadDialog
          trigger={
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm">
              <Plus className="h-3.5 w-3.5" /> Add a Lead
            </Button>
          }
        />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <RubricCard
          icon={<ContactRound className="h-4 w-4" />}
          label="Leads Submitted"
          value={leads.length}
          tone="default"
        />
        <RubricCard
          icon={<AlertTriangle className="h-4 w-4" />}
          label="Duplicates Flagged"
          value={dupCount}
          hint="Submitted after a similar-lead warning"
          tone="warning"
        />
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Full Name</TableHead>
              <TableHead>Country</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Reachout</TableHead>
              <TableHead>Applied</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {leads.length === 0 && (
              <TableRow>
                <TableCell colSpan={9} className="py-10 text-center text-sm text-muted-foreground">
                  No leads yet. Use <span className="font-medium text-foreground">Add a Lead</span> to submit your first one.
                </TableCell>
              </TableRow>
            )}
            {leads.map((l) => <LeadRow key={l.id} lead={l} />)}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function LeadRow({ lead }: { lead: RecruiterLead }) {
  return (
    <TableRow>
      <TableCell>
        <div className="flex items-center gap-2">
          <span className="font-medium">{lead.full_name}</span>
          {lead.dup_flagged && (
            <Badge variant="outline" className="border-warning/40 text-warning text-[10px]">
              duplicate flagged
            </Badge>
          )}
        </div>
        {lead.first_name && <div className="text-[11px] text-muted-foreground">{lead.first_name}</div>}
      </TableCell>
      <TableCell className="text-sm">{lead.country_of_residence || "—"}</TableCell>
      <TableCell className="text-sm">{lead.source}</TableCell>
      <TableCell className="text-sm">{lead.email_address || "—"}</TableCell>
      <TableCell className="text-sm">{lead.contact_number || "—"}</TableCell>
      <TableCell className="text-sm">{lead.reachout_date || "—"}</TableCell>
      <TableCell className="text-sm">{lead.application_date || "—"}</TableCell>
      <TableCell className="text-sm text-muted-foreground">
        {new Date(lead.created_at).toLocaleDateString()}
      </TableCell>
      <TableCell>
        <Badge variant="secondary" className="text-[10px]">Submitted</Badge>
      </TableCell>
    </TableRow>
  );
}

function RubricCard({
  icon, label, value, hint, tone,
}: { icon: React.ReactNode; label: string; value: number; hint?: string; tone: "default" | "warning" }) {
  const toneCls =
    tone === "warning"
      ? "border-warning/40 bg-warning/5 text-warning"
      : "border-border bg-card text-foreground";
  return (
    <div className={`rounded-xl border p-4 ${toneCls}`}>
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest opacity-80">
        {icon}
        {label}
      </div>
      <div className="mt-2 text-3xl font-semibold">{value}</div>
      {hint && <div className="mt-1 text-[11px] opacity-70">{hint}</div>}
    </div>
  );
}