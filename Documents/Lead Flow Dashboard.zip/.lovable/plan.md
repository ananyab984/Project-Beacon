## UX Refinement Pass — Enterprise Recruitment Platform

Scope: consistency, readability, and workflow improvements. No redesign. Preserve current tokens, spacing, and IA. All AI modules stay in code — hidden via a feature flag.

---

### 1. Feature Flag Infrastructure (foundation for #4, #5)

- Add `src/lib/feature-flags.ts` exporting `FEATURES = { ai: false }` plus a `useFeature(key)` hook.
- Wrap all AI-related nav items, dashboard cards, and route entries in `FEATURES.ai &&` guards.
- Keep every AI file (`owner.pipelines.tsx`, AI Draft Analytics, Enrichment, Data Health, AI Adoption tiles, `hooks/use-ai-tools.ts`, etc.) — only conceal from UI.

Hidden surfaces: Owner sidebar (AI Pipelines), Owner Overview (Data Health, AI Pipeline, Enrichment, AI Draft Analytics blocks), Recruiter KPIs (AI Adoption, Email Open Rate), Reports (AI sections).

---

### 2. Global Leads → CRM Table (Owner)

File: `src/routes/owner.leads.tsx`

- Remove Tabs (Table / Card / Pipeline). Keep only Table view. Delete Card branch usage of `LeadCard` on this page (component stays for other uses).
- Filter bar above table (sticky, single row, wraps on small): Country, Language, Service, Recruiter, Status (stage), Date Added (range). Search input stays leftmost — same placement pattern reused on all lead pages.
- Table upgrades:
  - Sticky header (`thead` with `sticky top-0`)
  - Row selection checkboxes + "select all"
  - Bulk actions bar (Assign, Change status, Export) appears when rows selected
  - Sortable columns (Name, Language, Stage, Date Added, Recruiter)
  - Pagination footer (25 / 50 / 100 per page)
- Add "Bulk Upload" button next to "Add Client" — see #11.
- Add `country` field where missing in `g3-mock.ts` leads (small extension; existing fields preserved).

---

### 3. Recruiter Navigation Rename

File: `src/routes/recruiter.tsx`

- Rename "My Performance" → **"Lead Performance"**. Route path stays `/recruiter/performance` for continuity; label + icon only.

---

### 4. Lead Performance Page Rebuild

File: `src/routes/recruiter.performance.tsx`

- Remove tiles: AI Adoption, Email Open Rate, Overall Score ring, Profile Quality, Placement-style metrics.
- Replace with workflow KPIs, each showing a **fraction / context**, not a bare number:
  - Assigned Leads (total)
  - Active Leads (in progress / assigned)
  - Leads Contacted (24 / 80)
  - Emails Sent
  - Replies Received
  - Positive Responses (16)
  - Follow-ups Pending (12)
  - Interviews Scheduled
  - Offers Sent
  - DNC Count
  - Response Rate (%)
- Extend `KpiTile` with a `context` prop (`"24 / 80"`) rendered under the value.
- Chart (Sent vs Replied stacked bars): stronger contrast (primary + accent on muted track), larger axis type, clearer legend chips, more Y padding, gridlines lighter.

---

### 5. Owner Dashboard Cleanup

File: `src/routes/owner.index.tsx`

- Hide via `FEATURES.ai`: Data Health, AI Pipeline, Enrichment, AI Draft Analytics blocks.
- Keep Escalations, Live Outreach 4-block strip, Recruiter roll-up.

---

### 6. Email Draft UX

File: `src/routes/recruiter.email-queue.tsx` (and draft dialog if present)

- Editable `To` field (input, not label).
- "Save Draft" button + autosave (debounced 1.5s to in-memory store on `recruiter-mock.ts`).
- Header status: `Unsaved changes` → `Saving…` → `Saved` (with timestamp).
- Preserve current visual style.

---

### 7. Conversations Module Naming

- Standardize label to **"Conversations"** everywhere (nav, header, page title).
- Add a channel tab strip at top of `recruiter.conversations.tsx`: `LinkedIn DMs` (active), `Email` (disabled + "Coming soon" pill), `WhatsApp` (disabled), `SMS` (disabled). Layout uses shared list/detail split so new channels drop in without redesign.

---

### 8. Contractor Portal

Files: `src/routes/contractor.tsx`, `contractor.index.tsx`

- Mirror recruiter chrome (same sidebar styling from #9).
- Explicitly no Global Leads route, no global search. Contractor sees only own submissions (already true — verify and enforce).
- Everything else identical.

---

### 9. Sidebar Readability Pass

Files: `src/routes/owner.tsx`, `recruiter.tsx`, `contractor.tsx`

- Increase text contrast: idle items `text-sidebar-foreground/85` (from /70); active gets bg + left accent bar + `font-medium`.
- Hover: subtle bg + icon color shift to primary.
- Section groups get a small uppercase caption label with generous top spacing.
- Icon stroke unchanged but tone brightened at active state.
- Same treatment applied consistently across owner / recruiter / contractor.

---

### 10. Reports — Time Saved Restructure

File: `src/routes/owner.reports.tsx`

- Replace single "19.4 hrs" tile with a 3-step vertical flow:
  - Manual Draft Time (config default e.g. 12 min/draft)
  - AI Draft Time (config default e.g. 3 min/draft)
  - **Total Time Saved** (computed)
- Benchmark values sourced from a constants object in `g3-mock.ts` so they're configurable later.
- Hidden entirely when `FEATURES.ai` is off (since it references AI). Left visible under flag.

---

### 11. Bulk Lead Upload

- "Bulk Upload" button on Global Leads (Owner) and Recruiter Leads.
- New dialog `src/components/g3/bulk-upload-dialog.tsx`:
  - Drop zone accepting `.csv` / `.xlsx`
  - "Download sample template" link (generates CSV client-side matching SEARCH schema fields)
  - Parse via `papaparse` (CSV) and `xlsx` (Excel) — add both via `bun add`
  - Preview first 10 rows in a table, duplicate check per row, "Import N leads" confirm
  - Mock append to `recruiter-mock.ts` store

---

### 12. Language & Labels

- Replace "3H Recruiters" → **"Recruiters"** wherever it appears.
- Sweep for other internal jargon (e.g. "Reachout", "P0/P1" chips get tooltip labels "Urgent / High / Normal / Low").

---

### 13 & 14. Consistency Pass

- Shared header pattern across Owner/Recruiter/Contractor: search input left, filters row, primary action button right.
- Verify shared token usage — no hardcoded colors introduced.
- Empty states: single reusable `<EmptyState>` component (icon + title + subtitle + optional CTA) applied to leads table, email queue, conversations.
- Table style: unified border radius `rounded-2xl`, header `bg-muted/50 text-[11px] uppercase`, row hover `bg-muted/40`, divide-y. Already close — normalize the few outliers.

---

### Technical Notes

- No schema changes beyond adding `country` to lead mock objects.
- No new routes. AI routes remain reachable if someone types the URL (acceptable — flag only hides nav).
- Packages to add: `papaparse`, `@types/papaparse`, `xlsx`.
- All changes stay in `src/routes/**`, `src/components/g3/**`, `src/lib/**`.

---

### Out of Scope

- Real backend / Lovable Cloud wiring
- Deleting any AI code
- Redesign of color palette, typography, or shell layout
- New pages beyond the bulk upload dialog

Proceed?